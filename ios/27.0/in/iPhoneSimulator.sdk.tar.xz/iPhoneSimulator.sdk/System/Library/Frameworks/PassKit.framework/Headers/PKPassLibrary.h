#if !__has_include(<PassKitCore/PKPassLibrary.h>) || PK_USE_PUBLIC_PASSKIT
//
//  PKPassLibrary.h
//    PassKit
//
//  Copyright (c) 2011 Apple, Inc. All rights reserved.
//
//  Threading contract: no concurrent usage.

#import <Foundation/Foundation.h>
#import <PassKit/PKPass.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, PKPassLibraryAddPassesStatus) {
    PKPassLibraryDidAddPasses,
    PKPassLibraryShouldReviewPasses,
    PKPassLibraryDidCancelAddPasses,
} API_AVAILABLE(ios(7.0), watchos(3.0));


typedef NS_ENUM(NSUInteger, PKAutomaticPassPresentationSuppressionResult) {
    PKAutomaticPassPresentationSuppressionResultNotSupported = 0,   // Suppression is not supported for this device
    PKAutomaticPassPresentationSuppressionResultAlreadyPresenting,  // Passes are already being presented and cannot be suppressed
    PKAutomaticPassPresentationSuppressionResultDenied,             // Suppression was denied due to lack of entitlement
    PKAutomaticPassPresentationSuppressionResultCancelled,          // Suppression was cancelled before the response handler was fired
    PKAutomaticPassPresentationSuppressionResultSuccess             // Suppression of automatic pass presentation was successful
} API_AVAILABLE(ios(9.0), watchos(10.2));

typedef NS_ENUM(NSInteger, PKPassLibraryCapability) {
    PKPassLibraryCapabilityBackgroundAddPasses,
} NS_SWIFT_NAME(PKPassLibrary.Capability) API_AVAILABLE(ios(26.0), watchos(26.0));

typedef NS_ENUM(NSInteger, PKPassLibraryAuthorizationStatus) {
    PKPassLibraryAuthorizationStatusNotDetermined = -1,
    PKPassLibraryAuthorizationStatusDenied = 0,
    PKPassLibraryAuthorizationStatusAuthorized = 1,
    PKPassLibraryAuthorizationStatusRestricted = 2,
} NS_SWIFT_NAME(PKPassLibrary.AuthorizationStatus) API_AVAILABLE(ios(26.0), watchos(26.0));

typedef NSUInteger PKSuppressionRequestToken;

API_AVAILABLE(ios(6.0), watchos(3.0))
@interface PKPassLibrary : NSObject

// The library is not available on iPad in 6.0.
+ (BOOL)isPassLibraryAvailable API_AVAILABLE(ios(6.0), watchos(3.0));

// These methods may be used to temporarily disable the automatic presentation of passes when a device encounters a contactless field.
// Use of these methods require an entitlement. Otherwise, requesting will always return a PKAutomaticPassPresentationSuppressionResultDenied as the result.
+ (PKSuppressionRequestToken)requestAutomaticPassPresentationSuppressionWithResponseHandler:(void(^)(PKAutomaticPassPresentationSuppressionResult result))responseHandler API_AVAILABLE(ios(9.0), watchos(10.2)) NS_EXTENSION_UNAVAILABLE("Not available to extensions");
+ (void)endAutomaticPassPresentationSuppressionWithRequestToken:(PKSuppressionRequestToken)requestToken API_AVAILABLE(ios(9.0), watchos(10.2)) NS_EXTENSION_UNAVAILABLE("Not available to extensions");
+ (BOOL)isSuppressingAutomaticPassPresentation API_AVAILABLE(ios(9.0), watchos(10.2)) NS_EXTENSION_UNAVAILABLE("Not available to extensions");

// If device supports adding payment passes, this method will return YES. Otherwise, NO will be returned.
+ (BOOL)isPaymentPassActivationAvailable API_DEPRECATED("Use -[PKPassLibrary isPaymentPassActivationAvailable] instead", ios(8.0, 9.0));

// If this pass library supports activating payment passes, this method will return YES. Otherwise, NO will be returned.
- (BOOL)isPaymentPassActivationAvailable API_DEPRECATED("Use -[PKPassLibrary isSecureElementPassActivationAvailable] instead", ios(9.0, API_TO_BE_DEPRECATED));

@property (nonatomic, assign, readonly, getter=isSecureElementPassActivationAvailable) BOOL secureElementPassActivationAvailable API_AVAILABLE(ios(13.4));

// These return only local passes the process is entitled to access.
- (NSArray<PKPass *> *)passes;
- (nullable PKPass *)passWithPassTypeIdentifier:(NSString *)identifier serialNumber:(NSString *)serialNumber;
- (NSSet<PKSecureElementPass *> *)passesWithReaderIdentifier:(NSString *)readerIdentifier;
- (NSArray<PKPass *> *)passesOfType:(PKPassType)passType API_AVAILABLE(ios(8.0), watchos(3.0));

// This returns the remote payment passes from attached devices
- (NSArray<PKPaymentPass *> *)remotePaymentPasses API_DEPRECATED("Use -[PKPassLibrary remoteSecureElementPasses] instead", ios(9.0, API_TO_BE_DEPRECATED));

@property (nonatomic, copy, readonly) NSArray<PKSecureElementPass *> *remoteSecureElementPasses API_AVAILABLE(ios(13.4));

- (void)removePass:(PKPass *)pass;

// This returns YES even if the process is not entitled to access the pass in the library.  An app like Mail is not entitled to get
// pass from the library, but it should avoid presenting UI for adding an email attachment pass that is already in the library.
- (BOOL)containsPass:(PKPass *)pass;

// This will fail if a pass with matching identifier and serial number is not already present in the library, or if the process
// is not entitled to access the pass. To add a completely new pass, use PKAddPassesViewController.
- (BOOL)replacePassWithPass:(PKPass *)pass;

// The user will be prompted to grant permission for the calling process to add passes to the Pass Library. The user may respond
// by allowing the passes to be added, or requesting to review the passes. The selection will be returned in the completionHandler
// as a PKPassLibraryAddPassesStatus. If PKPassLibraryPassesPresentReview is returned, you must present a PKAddPassesViewController
// initialized with the passes so that the user may review and add the passes manually. The completion handler for this method is
// called on an arbitrary queue - dispatch to the main queue if you're presenting UI.
- (void)addPasses:(NSArray<PKPass *> *)passes withCompletionHandler:(nullable void(^)(PKPassLibraryAddPassesStatus status))completion API_AVAILABLE(ios(7.0), watchos(3.0));

// Asks the user whether they want to add the given passes to their library. If the operation
// completes with `PKPassLibraryShouldReviewPasses`, then present an appropriately initialized
// `PKAddPassesViewController` so that the user may review the passes.
- (void)addPassesWithData:(NSArray<NSData *> *)passesData completionHandler:(void (^ NS_SWIFT_SENDABLE)(PKPassLibraryAddPassesStatus))completionHandler NS_SWIFT_NAME(addPasses(data:completion:)) API_AVAILABLE(ios(27.0), visionos(27.0)) API_UNAVAILABLE(macos) API_UNAVAILABLE(watchos);

// Asks the user whether they want to add the passes from the archive at the given URL to their
// library. If the operation completes with `PKPassLibraryShouldReviewPasses`, then present an
// appropriately initialized `PKAddPassesViewController` so that the user may review the passes.
- (void)addPassesFromArchiveAtFileURL:(NSURL *)passesArchiveFileURL completionHandler:(void (^ NS_SWIFT_SENDABLE)(PKPassLibraryAddPassesStatus))completionHandler NS_SWIFT_NAME(addPasses(fromArchiveAt:completion:)) API_AVAILABLE(ios(27.0), visionos(27.0)) API_UNAVAILABLE(macos) API_UNAVAILABLE(watchos);

// Asks the user whether they want to add the passes from the given archive to their library. If
// the operation completes with `PKPassLibraryShouldReviewPasses`, then present an appropriately
// initialized `PKAddPassesViewController` so that the user may review the passes.
- (void)addPassesFromArchiveWithData:(NSData *)passesArchiveData completionHandler:(void (^ NS_SWIFT_SENDABLE)(PKPassLibraryAddPassesStatus))completionHandler NS_SWIFT_NAME(addPasses(fromArchiveData:completion:)) API_AVAILABLE(ios(27.0), visionos(27.0)) API_UNAVAILABLE(macos) API_UNAVAILABLE(watchos);

// Opens the card setup flow (in Wallet on iPhone, Settings on iPad). Use this to direct a user to card setup directly from your app.
- (void)openPaymentSetup API_AVAILABLE(ios(8.3)) __WATCHOS_PROHIBITED;

// Opens the card setup flow with attribution tracking. The merchant identifier will be used to track provisioning success back to the calling application and campaign.
- (void)openPaymentSetupWithMerchantIdentifier:(NSString *)merchantIdentifier NS_SWIFT_NAME(openPaymentSetup(merchantIdentifier:)) NS_SWIFT_NAME(openPaymentSetup(merchantIdentifier:)) API_AVAILABLE(ios(26.4), visionos(26.4)) API_UNAVAILABLE(watchos);

// Presents the pass for use above the current application. The pass must already be in the pass library for this to have effect.
- (void)presentPaymentPass:(PKPaymentPass *)pass API_DEPRECATED("Use -[PKPassLibrary presentSecureElementPass:] instead", ios(10.0, API_TO_BE_DEPRECATED)) __WATCHOS_PROHIBITED;
- (void)presentSecureElementPass:(PKSecureElementPass *)pass API_AVAILABLE(ios(13.4)) API_UNAVAILABLE(watchos);


// Returns YES if either the current device or an attached device both supports adding payment passes and does not already contain
// a payment pass with the supplied primary account identifier.
- (BOOL)canAddPaymentPassWithPrimaryAccountIdentifier:(NSString *)primaryAccountIdentifier API_DEPRECATED("Use -[PKPassLibrary canAddSecureElementPassWithPrimaryAccountIdentifier] instead", ios(9.0, API_TO_BE_DEPRECATED));
- (BOOL)canAddSecureElementPassWithPrimaryAccountIdentifier:(NSString *)primaryAccountIdentifier NS_SWIFT_NAME(canAddSecureElementPass(primaryAccountIdentifier:)) API_AVAILABLE(ios(13.4));

// If the library can add Felica passes, this method will return YES. Otherwise, NO will be returned.
- (BOOL)canAddFelicaPass API_AVAILABLE(ios(10.1), watchos(3.1));

// These methods may be utilized to activate a payment pass that is provisioned but currently in the inactive state, by providing
// either a cryptographic OTP, or an activation code.
- (void)activatePaymentPass:(PKPaymentPass *)paymentPass withActivationData:(NSData *)activationData completion:(nullable void(^)(BOOL success, NSError *error))completion API_DEPRECATED("Use activateSecureElementPass:withActivationData:completion: instead", ios(8.0, API_TO_BE_DEPRECATED)) NS_SWIFT_DISABLE_ASYNC;
- (void)activatePaymentPass:(PKPaymentPass *)paymentPass withActivationCode:(NSString *)activationCode completion:(nullable void(^)(BOOL success, NSError *error))completion API_DEPRECATED("Use activatePaymentPass:withActivationData:completion: instead", ios(8.0, 9.0)) __WATCHOS_PROHIBITED NS_SWIFT_DISABLE_ASYNC;
- (void)activateSecureElementPass:(PKSecureElementPass *)secureElementPass withActivationData:(NSData *)activationData completion:(nullable void(^)(BOOL success, NSError * _Nullable error))completion NS_SWIFT_NAME(activate(_:activationData:completion:)) API_AVAILABLE(ios(13.4)) API_UNAVAILABLE(watchos);

- (void)signData:(NSData *)signData withSecureElementPass:(PKSecureElementPass *)secureElementPass completion:(void(^)(NSData * _Nullable signedData, NSData * _Nullable signature, NSError * _Nullable error))completion NS_SWIFT_NAME(sign(_:using:completion:)) API_DEPRECATED("No longer supported", ios(13.4, 26.0), watchos(6.2, 26.0));

- (void)encryptedServiceProviderDataForSecureElementPass:(PKSecureElementPass *)secureElementPass completion:(void(^)(NSDictionary * _Nullable encryptedServiceProviderData, NSError* _Nullable error))completion NS_SWIFT_NAME(encryptedServiceProviderData(for:completion:)) API_AVAILABLE(ios(16.0), watchos(9.0));
// Returns custom data for a given secure element pass, if supported by that pass
- (void)serviceProviderDataForSecureElementPass:(PKSecureElementPass *)secureElementPass completion:(void(^)(NSData * _Nullable serviceProviderData, NSError* _Nullable error))completion NS_SWIFT_NAME(serviceProviderData(for:completion:)) API_AVAILABLE(ios(15.0), watchos(8.0));

// Check TCC authorization for capability
- (PKPassLibraryAuthorizationStatus)authorizationStatusForCapability:(PKPassLibraryCapability)capability API_AVAILABLE(ios(26.0), watchos(26.0));

// Request authorization for capability, saved in TCC
- (void)requestAuthorizationForCapability:(PKPassLibraryCapability)capability completion:(void (^)(PKPassLibraryAuthorizationStatus status))completion API_AVAILABLE(ios(26.0), watchos(26.0));

@end

// This notification is issued by a library instance, with that instance as the sender.  If there are no instantiated library objects,
// no notifications. There are no guarantees about what thread or queue these come in on.
typedef NSString * PKPassLibraryNotificationName NS_EXTENSIBLE_STRING_ENUM;
extern PKPassLibraryNotificationName const PKPassLibraryDidChangeNotification API_AVAILABLE(ios(6.0), watchos(3.0));
extern PKPassLibraryNotificationName const PKPassLibraryRemotePaymentPassesDidChangeNotification API_AVAILABLE(ios(9.0), watchos(3.0));

// Entries in user info dictionary for PKPassLibraryDidChangeNotification.
// - PKPassLibraryAddedPassesUserInfoKey is the key for an array of passes
// - PKPassLibraryReplacementPassesUserInfoKey is the key for an array of passes
// - PKPassLibraryRemovedPassInfosUserInfoKey is the key for an array of dictionaries, each of which has keys
//   PKPassLibraryPassTypeIdentifierUserInfoKey and PKPassLibrarySerialNumberUserInfoKey mapping to strings.
typedef NSString * PKPassLibraryNotificationKey NS_STRING_ENUM;
extern PKPassLibraryNotificationKey const PKPassLibraryAddedPassesUserInfoKey API_AVAILABLE(ios(6.0), watchos(3.0));
extern PKPassLibraryNotificationKey const PKPassLibraryReplacementPassesUserInfoKey API_AVAILABLE(ios(6.0), watchos(3.0));
extern PKPassLibraryNotificationKey const PKPassLibraryRemovedPassInfosUserInfoKey API_AVAILABLE(ios(6.0), watchos(3.0));

extern PKPassLibraryNotificationKey const PKPassLibraryPassTypeIdentifierUserInfoKey API_AVAILABLE(ios(6.0), watchos(3.0));
extern PKPassLibraryNotificationKey const PKPassLibrarySerialNumberUserInfoKey API_AVAILABLE(ios(6.0), watchos(3.0));
extern PKPassLibraryNotificationKey const PKPassLibraryRecoveredPassesUserInfoKey API_AVAILABLE(ios(15.0), watchos(8.0));

NS_ASSUME_NONNULL_END

#else
#import <TargetConditionals.h>
#import <PassKitCore/PKPassLibrary.h>
#endif